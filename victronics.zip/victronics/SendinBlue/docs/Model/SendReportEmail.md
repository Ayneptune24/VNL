# SendReportEmail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**to** | **string[]** | Email addresses of the recipients | 
**body** | **string** | Custom text message to be presented in the report email. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


