# NoteData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **string** | Text content of a note | 
**contactIds** | **int[]** | Contact Ids linked to a note | [optional] 
**dealIds** | **string[]** | Deal Ids linked to a note | [optional] 
**companyIds** | **string[]** | Company Ids linked to a note | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


