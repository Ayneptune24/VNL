# AbTestCampaignResultStatistics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**openers** | [**\SendinBlue\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 
**clicks** | [**\SendinBlue\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 
**unsubscribed** | [**\SendinBlue\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 
**hardBounces** | [**\SendinBlue\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 
**softBounces** | [**\SendinBlue\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 
**complaints** | [**\SendinBlue\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


