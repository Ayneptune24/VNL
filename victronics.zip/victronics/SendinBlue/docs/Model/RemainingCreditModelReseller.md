# RemainingCreditModelReseller

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sms** | **double** | SMS Credits remaining for reseller account | 
**email** | **double** | Email Credits remaining for reseller account | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


