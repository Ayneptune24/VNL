# DealAttributesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**internalName** | **string** |  | [optional] 
**label** | **string** |  | [optional] 
**attributeTypeName** | **string** |  | [optional] 
**attributeOptions** | **object[]** |  | [optional] 
**isRequired** | **bool** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


