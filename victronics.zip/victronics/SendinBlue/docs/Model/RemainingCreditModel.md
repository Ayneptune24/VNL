# RemainingCreditModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**child** | [**\SendinBlue\Client\Model\RemainingCreditModelChild**](RemainingCreditModelChild.md) |  | 
**reseller** | [**\SendinBlue\Client\Model\RemainingCreditModelReseller**](RemainingCreditModelReseller.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


