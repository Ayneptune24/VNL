# ConversationsMessageFileImageInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **int** | Width of the image | [optional] 
**height** | **int** | height of the image | [optional] 
**previewUrl** | **string** | URL of the preview | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


