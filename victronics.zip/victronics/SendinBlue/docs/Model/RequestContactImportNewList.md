# RequestContactImportNewList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**listName** | **string** | List with listName will be created first and users will be imported in it (Mandatory if listIds is empty). | [optional] 
**folderId** | **int** | Id of the folder where this new list shall be created (Mandatory if listName is not empty). | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


