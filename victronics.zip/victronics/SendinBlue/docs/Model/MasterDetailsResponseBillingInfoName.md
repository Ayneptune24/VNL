# MasterDetailsResponseBillingInfoName

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**givenName** | **string** | First name for billing | [optional] 
**familyName** | **string** | Last name for billing | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


