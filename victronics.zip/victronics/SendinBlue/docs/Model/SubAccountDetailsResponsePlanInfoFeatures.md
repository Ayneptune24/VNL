# SubAccountDetailsResponsePlanInfoFeatures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inbox** | [**\SendinBlue\Client\Model\SubAccountDetailsResponsePlanInfoFeaturesInbox**](SubAccountDetailsResponsePlanInfoFeaturesInbox.md) |  | [optional] 
**landingPage** | [**\SendinBlue\Client\Model\SubAccountDetailsResponsePlanInfoFeaturesLandingPage**](SubAccountDetailsResponsePlanInfoFeaturesLandingPage.md) |  | [optional] 
**users** | [**\SendinBlue\Client\Model\SubAccountDetailsResponsePlanInfoFeaturesUsers**](SubAccountDetailsResponsePlanInfoFeaturesUsers.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


